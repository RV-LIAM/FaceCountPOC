public class DataModal {

    // string variables for our name and job
    private String content;

    public DataModal(String c) {
        this.content = c;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String c) {
        this.content = c;
    }
}
