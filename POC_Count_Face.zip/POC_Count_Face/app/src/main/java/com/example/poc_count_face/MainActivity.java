package com.example.poc_count_face;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
//for
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

import android.util.Base64;
import android.util.Base64OutputStream;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {


    // One Button
    Button BSelectImage;

    // One Preview Image
    ImageView IVPreviewImage;

    TextView superTextView;

    // constant to compare
    // the activity result code
    int SELECT_PICTURE = 200;

    static String returnString="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // register the UI widgets with their appropriate IDs
        BSelectImage = findViewById(R.id.BSelectImage);
        IVPreviewImage = findViewById(R.id.IVPreviewImage);
        superTextView = findViewById(R.id.superTextView);

        // handle the Choose Image button to trigger
        // the image chooser function
        BSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageChooser();
            }
        });
    }

    // this function is triggered when
    // the Select Image Button is clicked
    void imageChooser() {

        // create an instance of the
        // intent of the type image
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        // pass the constant to compare it
        // with the returned requestCode
        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);
    }

    // this function is triggered when user
    // selects the image from the imageChooser
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == SELECT_PICTURE) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    // update the preview image in the layout
                    IVPreviewImage.setImageURI(selectedImageUri);
                    Bitmap bitmap=((BitmapDrawable)IVPreviewImage.getDrawable()).getBitmap();

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.logo);
//                  InputStream imageStream = getContentResolver().openInputStream(data.);
//                    Bitmap bitmap = BitmapFactory.decodeStream(imageStream);
                    if (bitmap == null) {
//                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri("abc"));
                    }
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                        byte[] imageBytes = baos.toByteArray();
                        String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                        makeRequest(imageString);
//                        superTextView.setText(returnString);
                    }

                }
            }
        }

    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    public void makeRequest(String json) {
        returnString="";
        String uri = "http://10.0.2.2:5000/api/files/first.jpg";
        HttpURLConnection urlConnection;
        String url;
        String data = json;
        String result = null;
        JSONObject requestObject = new JSONObject();
        try {
            requestObject.put("image", data);
            requestObject.put("other_key", "value");
        } catch (Exception e)
        {

        }
        try {
            //Connect

            OkHttpClient client = new OkHttpClient();
            RequestBody body = RequestBody.create(JSON,requestObject.toString());
            Request request = new Request.Builder()
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept" , "text/plain")
                    .url(uri)
                    .post(body)
                    .build();

            String getURL = "http://10.0.2.2:5000/api/num";
            Request getRequest = new Request.Builder()
                    .url(getURL)
                    .build();
            Call call2 = client.newCall(getRequest);
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(final Call call, IOException e) {
                    e.printStackTrace();
                }
                @Override
                public void onResponse(final Call call, Response response) throws IOException {
                    try {
                        if (response.isSuccessful()) {

                            call2.enqueue(new Callback() {
                                @Override
                                public void onFailure(final Call call2, IOException e2) {
                                    e2.printStackTrace();
                                }

                                @Override
                                public void onResponse(final Call cal2, Response response2) throws IOException {
                                    try {
                                        if (response2.isSuccessful())
                                        {
                                            returnString=response2.body().string();
                                        } else {
                                            returnString="cannot detect faces";
                                        }
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                superTextView.setText(returnString);
                                            }
                                        });
                                    } catch (Exception e2) {
                                        e2.printStackTrace();
                                    }
                                }
                            });

                        }
                    else {
                            returnString="Error";
                        }
//                        superTextView.setText(returnString);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
//            okhttp3.Response response = client.newCall(request).execute();
//            return response.body().string();
//            urlConnection = (HttpURLConnection) ((new URL(uri).openConnection()));
//            urlConnection.setDoOutput(true);
//            urlConnection.setRequestProperty("Content-Type", "application/json");
//            urlConnection.setRequestProperty("Accept", "text/plain");
//            urlConnection.setRequestMethod("POST");
//            urlConnection.connect();
//
//            //Write
//            OutputStream outputStream = urlConnection.getOutputStream();
//            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
//            writer.write(data);
//            writer.close();
//            outputStream.close();
//
//            //Read
//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(), "UTF-8"));
//
//            String line = null;
//            StringBuilder sb = new StringBuilder();
//
//            while ((line = bufferedReader.readLine()) != null) {
//                sb.append(line);
//            }
//
//            bufferedReader.close();
//            result = sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
