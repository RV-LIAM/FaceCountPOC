import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {

    String BASE_URL = "http://127.0.0.1:5000";
    @POST("/api/files/<filename>")
        //on below line we are creating a method to post our data.
    Call<DataModal> createPost(@Body DataModal dataModal);
}