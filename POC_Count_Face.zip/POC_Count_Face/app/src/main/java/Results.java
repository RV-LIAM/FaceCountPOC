import com.google.gson.annotations.SerializedName;

public class Results {

    @SerializedName("facesnum")
    private String superNum;


    public Results(String num) {
        this.superNum = num;
    }

    public String getNumber() {
        return superNum;
    }
}